from TTTsolver import TicTacToeSolver
from TCPUDPServer import Server
import numpy as np
import json

def handleRequest(message, address):
    board = np.array(json.loads(message)["board"])
    x,y = map(int, tictactoe.solveState(board))
    print(x,y)
    return json.dumps({"x":x, "y":y})

tictactoe = TicTacToeSolver("policy_3_3_x.pkl","policy_3_3_o.pkl")
server = Server("TCP", 8080)
server.listen(handleRequest)